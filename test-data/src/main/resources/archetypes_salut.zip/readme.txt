These are archetypes exported from the Clinical Knowledge Manager.
Export time: Wed May 20 11:36:26 CEST 2026